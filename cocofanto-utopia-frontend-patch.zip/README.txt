COCOFANTO FRONTEND PATCH
========================

This is a FRONTEND-ONLY patch for your original Utopia project.

Files changed:
  main/index.html
  main/main.html
  main/img/cocofanto.png

What it changes:
- Renames visible UI to Cocofanto Search
- Adds the Cocofanto mascot
- Removes visible games/settings/Discord/ads/footer clutter from the main page
- Replaces the old visual design with a minimalist white search page
- Preserves the existing #search element and js/go.js reference

What it does NOT change:
- index.js / index.mjs
- package.json
- service workers
- uv/ files
- proxy libraries
- backend/server configuration
- networking logic

HOW TO APPLY
------------
1. Keep your original Utopia project.
2. Copy the files from this patch into the matching paths.
3. Allow them to replace the existing frontend files.
4. Leave every other original project file untouched.

This patch is intentionally not a stripped or deployable proxy package.
